#!/usr/bin/env python3
"""
Spirit Forge — Phase 2: Distill (炼)

Extract structured patterns from raw persona research. Reads the
raw-research directory and produces a persona-profile.json with
expertise domains, decision heuristics, communication style markers,
gotchas, tool preferences, and reference canon.

Usage:
    python distill.py <raw-research-dir> [--output persona-profile.json]
"""

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Optional

# Allow running from skill root or scripts/ directory
_skill_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_skill_root))


# ---------------------------------------------------------------------------
# Schema (also defined in examples/persona-profile.schema.json)
# ---------------------------------------------------------------------------

PROFILE_SCHEMA = {
    "persona_name": "",
    "timestamp": "",
    "sources_processed": [],
    "expertise": [],        # [{"domain": str, "level": "expert"|"proficient"|"familiar", "evidence": [str]}]
    "heuristics": [],       # [{"when": str, "then": str, "because": str, "source": str}]
    "style": {              # Communication style markers
        "formality": 5,     # 1-10
        "phrases": [],      # Signature phrases
        "patterns": [],     # Sentence patterns
        "explanation_style": "",  # analogy-driven | first-principles | example-first
    },
    "tools": [],            # [{"name": str, "usage": str, "source": str}]
    "gotchas": [],          # [{"pattern": str, "fix": str, "source": str}]
    "canon": [],            # [{"title": str, "type": "paper"|"book"|"talk"|"repo", "cited_in": [str]}]
    "contradictions": [],   # [{"stated": str, "observed": str, "source": str}]
    "confidence": {
        "expertise": "medium",
        "heuristics": "medium",
        "style": "medium",
        "gotchas": "medium",
    },
}


# ---------------------------------------------------------------------------
# Main distill function
# ---------------------------------------------------------------------------

def distill(raw_research_dir: str, output_path: Optional[str] = None) -> dict:
    """Extract structured persona profile from raw research.

    Args:
        raw_research_dir: Path to directory containing raw-research/*.md and *.json files
        output_path: Where to write persona-profile.json

    Returns:
        Populated persona profile dict
    """
    research = Path(raw_research_dir)
    if not research.exists():
        raise FileNotFoundError(f"Research directory not found: {raw_research_dir}")

    _print_header("Phase 2: Distill (炼)")

    profile = dict(PROFILE_SCHEMA)  # Deep copy
    profile["timestamp"] = _now()

    # Load meta
    meta = _load_json(research / "meta.json")
    if meta:
        profile["persona_name"] = meta.get("target_raw", "unknown")
        profile["sources_processed"] = meta.get("files_written", [])

    # Read all markdown research files
    research_texts = {}
    for md_file in research.glob("*.md"):
        research_texts[md_file.stem] = md_file.read_text(encoding="utf-8")
    for json_file in research.glob("*.json"):
        if json_file.stem == "meta":
            continue
        try:
            data = _load_json(json_file)
            if isinstance(data, str):
                research_texts[json_file.stem] = data
            elif isinstance(data, dict):
                research_texts[json_file.stem] = json.dumps(data, ensure_ascii=False, indent=2)
            else:
                research_texts[json_file.stem] = str(data)
        except Exception:
            pass

    combined = "\n\n".join(research_texts.values())

    # ---- Ingest Firecrawl structured JSON (if exists) ----
    firecrawl_data = _ingest_firecrawl_json(str(research))

    # ---- Extract expertise domains ----
    print("  Extracting expertise domains ...")
    profile["expertise"] = _extract_expertise(research_texts, combined)

    # ---- Extract heuristics (Firecrawl → regex baseline) ----
    if firecrawl_data.get("heuristics"):
        print(f"  → Using {len(firecrawl_data['heuristics'])} heuristics from Firecrawl extract")
        profile["heuristics"] = firecrawl_data["heuristics"]
    else:
        print("  Extracting decision heuristics ...")
        profile["heuristics"] = _extract_heuristics(research_texts, combined)

    # ---- Extract style markers ----
    print("  Extracting communication style ...")
    profile["style"] = _extract_style(research_texts, combined)

    # ---- Extract tool preferences ----
    print("  Extracting tool preferences ...")
    profile["tools"] = _extract_tools(combined)

    # ---- Extract gotchas (Firecrawl → regex baseline) ----
    print("  Extracting gotchas ...")
    if firecrawl_data.get("gotchas"):
        print(f"  → Using {len(firecrawl_data['gotchas'])} gotchas from Firecrawl extract")
        profile["gotchas"] = firecrawl_data["gotchas"]
    else:
        profile["gotchas"] = _extract_gotchas(research_texts, combined)

    # ---- Extract heuristics (Firecrawl → regex baseline) ----
    if firecrawl_data.get("heuristics"):
        print(f"  → Using {len(firecrawl_data['heuristics'])} heuristics from Firecrawl extract")
        profile["heuristics"] = firecrawl_data["heuristics"]
    # (heuristics already extracted above by regex if no firecrawl data)

    # ---- Extract canon ----
    print("  Extracting reference canon ...")
    profile["canon"] = _extract_canon(combined)

    # ---- Assess confidence ----
    profile["confidence"] = _assess_confidence(profile)

    # ---- Quality gate ----
    if len(profile["expertise"]) < 1 or len(profile["gotchas"]) < 3:
        print("  ⚠ DISTILL QUALITY GATE: insufficient signal extracted")
        print(f"     expertise: {len(profile['expertise'])} domains")
        print(f"     gotchas: {len(profile['gotchas'])} patterns")
        print(f"     heuristics: {len(profile['heuristics'])} rules")
        profile["_quality_gate"] = {
            "status": "insufficient",
            "reason": f"Low extraction yield: {len(profile['expertise'])} domains, {len(profile['gotchas'])} gotchas",
            "recommendation": "Re-run capture at L2 or L3 depth, or manually enrich raw-research/ with additional source content."
        }

    # ---- Write extraction tasks for Claude (if regex insufficient) ----
    tasks = []
    if len(profile["gotchas"]) < 3:
        tasks.append({
            "task": "Gotcha Extraction",
            "instruction": "Read all .md files in raw-research/. Identify patterns this person consistently catches that others miss. For each: describe the common mistake (pattern) and the correct approach (fix). Aim for 5-15 gotchas.",
            "output_field": "gotchas",
            "output_format": '[{"pattern": "...", "fix": "...", "source": "claude-extraction"}, ...]',
        })
    if len(profile["heuristics"]) < 3:
        tasks.append({
            "task": "Heuristic Extraction",
            "instruction": "Read all .md files in raw-research/. Extract decision rules, principles, and patterns of thinking. For each: what condition triggers this response? What's the preferred action? Why? Aim for 5-10 heuristics.",
            "output_field": "heuristics",
            "output_format": '[{"when": "...", "then": "...", "because": "...", "source": "claude-extraction"}, ...]',
        })
    if tasks:
        tasks_path = research / "extraction-tasks.md"
        with open(tasks_path, "w") as f:
            f.write("# Extraction Tasks for Claude\n\n")
            f.write(f"Persona: {profile.get('persona_name', 'unknown')}\n\n")
            for i, t in enumerate(tasks, 1):
                f.write(f"## Task {i}: {t['task']}\n\n")
                f.write(f"{t['instruction']}\n\n")
                f.write(f"**Output field**: `{t['output_field']}`\n\n")
                f.write(f"**Output format**:\n```json\n{t['output_format']}\n```\n\n")
                f.write(f"Write results to the `{t['output_field']}` array in persona-profile.json.\n\n---\n\n")
        print(f"  → Wrote {len(tasks)} extraction tasks to extraction-tasks.md for Claude to complete")

    # Write output
    if output_path is None:
        parent = research.parent
        output_path = str(parent / "persona-profile.json")
    with open(output_path, "w") as f:
        json.dump(profile, f, ensure_ascii=False, indent=2)

    _print_footer(output_path, profile)
    return profile


# ---------------------------------------------------------------------------
# Extractors
# ---------------------------------------------------------------------------

def _extract_expertise(texts: dict, combined: str) -> list[dict]:
    """Extract expertise domains from research texts using word-boundary matching.

    Uses \b boundaries to prevent false positives (e.g., 'go' matching in 'gotcha').
    Applies a blacklist for common short words that slip through.
    """
    expertise = []

    # Domain keywords: (display_name, regex_pattern)
    # Patterns use \b for word boundary to avoid substring false positives
    tech_domains: list[tuple[str, str]] = [
        ("react", r"\breact\b"),
        ("javascript", r"\bjavascript\b"),
        ("typescript", r"\btype\s*script\b"),
        ("python", r"\bpython\b"),
        ("rust", r"\brust\b"),
        ("go (golang)", r"\bgolang\b|\bgo\s+language\b|\bgo\s+programming\b"),
        ("clojure", r"\bclojure\b"),
        ("haskell", r"\bhaskell\b"),
        ("elixir", r"\belixir\b"),
        ("scala", r"\bscala\b"),
        ("java", r"\bjava\b"),
        ("c++", r"\bc\+\+\b"),
        ("c#", r"\bc#\b"),
        ("frontend", r"\bfront[\s-]*end\b"),
        ("backend", r"\bback[\s-]*end\b"),
        ("full-stack", r"\bfull[\s-]*stack\b"),
        ("devops", r"\bdevops\b"),
        ("infrastructure", r"\binfrastructure\b"),
        ("distributed systems", r"\bdistributed\s+systems?\b"),
        ("compilers", r"\bcompilers?\b"),
        ("databases", r"\bdatabases?\b|\bsql\b"),
        ("machine learning", r"\bmachine\s+learning\b|\bml\b"),
        ("ai / llm", r"\bai\b|\bllms?\b|\blarge\s+language\s+models?\b"),
        ("design", r"\bdesign\b"),
        ("ux", r"\bux\b|\buser\s+experience\b"),
        ("accessibility", r"\baccessibility\b|\ba11y\b"),
        ("performance", r"\bperformance\b|\boptimization\b"),
        ("security", r"\bsecurity\b"),
        ("testing", r"\btesting\b|\btest\s+driven\b|\bunit\s+tests?\b"),
        ("architecture", r"\barchitecture\b|\bdesign\s+patterns?\b"),
        ("api design", r"\bapi\s+design\b|\brest\s+api\b|\bgraphql\b"),
        ("open source", r"\bopen[\s-]*source\b"),
        ("vue", r"\bvue\b"),
        ("angular", r"\bangular\b"),
        ("svelte", r"\bsvelte\b"),
        ("node.js", r"\bnode\.?js\b|\bnode\b"),
        ("deno", r"\bdeno\b"),
        ("docker", r"\bdocker\b"),
        ("kubernetes", r"\bkubernetes\b|\bk8s\b"),
        ("aws", r"\baws\b|\bamazon\s+web\s+services\b"),
        ("cloud", r"\bcloud\b"),
        ("linux", r"\blinux\b"),
        ("git", r"\bgit\b|\bgithub\b"),
        ("functional programming", r"\bfunctional\s+programming\b|\bfp\b"),
        ("writing / technical writing", r"\btechnical\s+writing\b|\bwriting\s+style\b|\bauthor\b"),
        ("teaching / mentoring", r"\bteaching\b|\bmentoring\b|\beducation\b|\bspeaking\b"),
    ]

    # Blacklist: common short words that might match domain patterns as substrings
    blacklist = {"go", "ai", "it", "we", "can", "set", "run", "use", "new", "one", "two", "top", "get", "put", "api", "css", "dom", "web", "app", "ide", "npm", "ci"}

    lower = combined.lower()
    domain_counts: dict[str, int] = {}
    domain_patterns: dict[str, str] = {}

    for display_name, pattern in tech_domains:
        matches = re.findall(pattern, lower, re.IGNORECASE)
        if matches:
            count = len(matches)
            # Filter blacklist: if the display_name maps to a blacklisted word and
            # the match count is suspiciously low (< 5 in a long text), skip it
            if display_name.split()[0] in blacklist and count < 5:
                continue
            domain_counts[display_name] = count
            domain_patterns[display_name] = pattern

    for domain, count in sorted(domain_counts.items(), key=lambda x: -x[1])[:10]:
        level = "expert" if count >= 8 else "proficient" if count >= 3 else "familiar"
        evidence = []
        pattern = domain_patterns.get(domain, domain)
        for fname, text in texts.items():
            found = len(re.findall(pattern, text, re.IGNORECASE))
            if found > 0:
                evidence.append(f"{fname}: {found} mentions")
        expertise.append({
            "domain": domain,
            "level": level,
            "evidence": evidence[:3],
        })

    return expertise


def _extract_heuristics(texts: dict, combined: str) -> list[dict]:
    """Extract decision heuristics from research texts.

    Supports both first-person (I prefer) and third-person (he prefers, the author chooses)
    patterns. Also handles declarative rules and principles.
    """
    heuristics = []

    # Pattern-based extraction — first + third person variants
    patterns = [
        # First-person conditional: "When X, I prefer Y because Z"
        (r"(?:when|if)\s+(.+?),\s*(?:I\s+)?(?:prefer|use|choose|go with|reach for|recommend)\s+(.+?)(?:because|since|as)\s+(.+)", "conditional"),
        # Third-person conditional: "When X, he prefers Y because Z"
        (r"(?:when|if)\s+(.+?),\s*(?:he|she|they|the\s+author)\s+(?:prefers?|uses?|chooses?|reaches?\s+for|recommends?)\s+(.+?)(?:because|since|as)\s+(.+)", "conditional-3p"),
        # Absolute rules: "Always/never X because Y"
        (r"(?:always|never)\s+(.+?)(?:because|since)\s+(.+)", "absolute"),
        # Rule of thumb: "The rule of thumb is X"
        (r"(?:the\s+)?rule\s+(?:of\s+)?thumb\s+(?:is|:)\s*(.+)", "rule_of_thumb"),
        # Experiential (first-person): "I've found X because Y"
        (r"(?:I've\s+found|I\s+find|in\s+my\s+experience)\s+(?:that\s+)?(.+?)(?:because|since)\s+(.+)", "experiential"),
        # Experiential (third-person): "He's found X because Y"
        (r"(?:he's|she's|they've)\s+found\s+(?:that\s+)?(.+?)(?:because|since)\s+(.+)", "experiential-3p"),
        # Principle statement: "The key insight/principle/approach is X"
        (r"(?:the|a|one)\s+(?:key\s+)?(?:insight|principle|approach|pattern|idea)\s+(?:is|:)\s*(.+)", "principle"),
        # Trade-off framing: "X vs Y" or "X over Y when Z"
        (r"(?:prefers?|chooses?|goes?\s+with)\s+(.+?)\s+(?:over|rather\s+than|instead\s+of)\s+(.+?)(?:when|because|for)\s+(.+)", "tradeoff"),
        # "Don't X, instead Y"
        (r"(?:don't|do\s+not)\s+(.+?),\s*(?:instead|rather|prefer)\s+(.+)", "correction"),
    ]

    for pattern, htype in patterns:
        matches = re.findall(pattern, combined, re.IGNORECASE)
        for match in matches:
            if isinstance(match, tuple):
                parts = [m for m in match if m]
                if len(parts) >= 2:
                    heuristics.append({
                        "when": parts[0].strip()[:200],
                        "then": parts[1].strip()[:200],
                        "because": parts[2].strip()[:200] if len(parts) > 2 else "",
                        "source": f"regex:{htype}",
                    })
            elif isinstance(match, str) and len(match.strip()) > 15:
                heuristics.append({
                    "when": "",
                    "then": match.strip()[:200],
                    "because": "",
                    "source": f"regex:{htype}",
                })

    # Deduplicate by 'then' field (most distinctive)
    seen = set()
    unique = []
    for h in heuristics:
        key = h["then"].lower()[:80]
        if key not in seen:
            seen.add(key)
            unique.append(h)

    return unique[:20]  # Cap at 20 most relevant heuristics


def _extract_style(texts: dict, combined: str) -> dict:
    """Extract communication style markers.

    Filters out Markdown formatting before analysis to avoid extracting
    headings and syntax markers as style patterns.
    """
    # Strip Markdown formatting before analysis
    cleaned = _strip_markdown(combined)
    cleaned_lower = cleaned.lower()

    style = {
        "formality": 5,
        "phrases": [],
        "patterns": [],
        "explanation_style": "",
    }

    # Formality heuristics
    informal_signals = len(re.findall(r'!{1,3}', cleaned)) + \
                       len(re.findall(r"\b(don't|can't|won't|i'm|you're|it's|that's|we're|they're)\b", cleaned_lower)) + \
                       len(re.findall(r'[\U0001F300-\U0001F9FF]', cleaned))
    formal_signals = len(re.findall(r"\b(therefore|however|consequently|furthermore|nevertheless|accordingly|moreover|thus|hence)\b", cleaned_lower))

    if informal_signals > formal_signals * 3:
        style["formality"] = 3
    elif formal_signals > informal_signals * 3:
        style["formality"] = 7
    else:
        style["formality"] = 5

    # Common phrases from cleaned text (2-4 word ngrams, ≥3 occurrences)
    words = re.findall(r'\b[a-z]+\b', cleaned_lower)
    trigrams = Counter()
    # Common stop words to skip when building ngrams
    stop_ngrams = {"the", "this", "that", "with", "from", "have", "been", "were", "they", "their", "them"}
    for i in range(len(words) - 2):
        trigram = " ".join(words[i:i+3])
        if trigram in stop_ngrams:
            continue
        if 10 < len(trigram) < 40:
            trigrams[trigram] += 1
    style["phrases"] = [p for p, c in trigrams.most_common(30) if c >= 3][:10]

    # Explanation style
    if "for example" in cleaned_lower or "e.g." in cleaned_lower or "here's an example" in cleaned_lower:
        style["explanation_style"] = "example-first"
    elif "because" in cleaned_lower or "the reason" in cleaned_lower or "why" in cleaned_lower:
        style["explanation_style"] = "first-principles"
    elif "think of it" in cleaned_lower or "imagine" in cleaned_lower or "like" in cleaned_lower:
        style["explanation_style"] = "analogy-driven"
    else:
        style["explanation_style"] = "balanced"

    # Sentence patterns (filtered text)
    sentences = re.split(r'[.!?]+', cleaned)
    valid_sentences = [s for s in sentences[:100] if len(s.split()) >= 3]
    if valid_sentences:
        avg_len = sum(len(s.split()) for s in valid_sentences) / len(valid_sentences)
        if avg_len < 10:
            style["patterns"].append("short-sentences")
        elif avg_len > 30:
            style["patterns"].append("long-sentences")
        else:
            style["patterns"].append("balanced")

    # Rhetorical devices
    if re.search(r'\?', cleaned) and len(re.findall(r'\?', cleaned)) > 3:
        style["patterns"].append("uses-rhetorical-questions")
    if re.search(r'(?:not X, but Y|not only.*but also)', cleaned):
        style["patterns"].append("contrast-heavy")
    if re.search(r'(?:imagine|picture this|visualize)', cleaned_lower):
        style["patterns"].append("visual-language")

    # Style analysis: textacy (English), jieba (Chinese), or fallback
    cleaned = _strip_markdown(combined)
    if _detect_chinese(cleaned):
        ja = _jieba_style(cleaned)
        style["dimensions"] = {
            "engine": ja.get("engine", "unknown"),
            "chinese_word_count": ja.get("word_count", 0),
            "chinese_ttr": ja.get("ttr", 0),
            "top_chinese_words": ja.get("top_words", [])[:10],
        }
    else:
        ta = _textacy_style(cleaned)
        if ta:
            style["dimensions"] = {
                "engine": "textacy",
                "n_words": ta["n_words"],
                "n_unique_words": ta["n_unique_words"],
                "n_sentences": ta["n_sentences"],
                "readability": ta["readability"],
                "diversity": ta["diversity"],
                "entropy": ta["entropy"],
                "key_terms": ta["key_terms"],
                "pos_distribution": ta["pos_distribution"],
            }
        else:
            fb = _fallback_style(cleaned)
            style["dimensions"] = {
                "engine": "fallback",
                "n_words": fb["n_words"],
                "n_unique_words": fb["n_unique_words"],
                "n_sentences": fb["n_sentences"],
                "avg_sentence_length": fb["avg_sentence_length"],
            }

    return style


# ---------------------------------------------------------------------------
# Textacy-based style analysis (replaces 7 hand-rolled functions)
# ---------------------------------------------------------------------------

def _detect_chinese(text: str) -> bool:
    """Return True if text contains CJK Unified Ideographs."""
    return bool(re.search(r'[一-鿿㐀-䶿豈-﫿]', text))


def _ingest_firecrawl_json(raw_dir: str) -> dict[str, list]:
    """Ingest Firecrawl extract JSON files directly into profile fields.

    Firecrawl extract produces structured JSON matching persona-profile schema.
    If these files exist, merge them directly — bypass regex extraction.
    """
    result: dict[str, list] = {}
    raw = Path(raw_dir)

    for field in ("gotchas", "heuristics"):
        for candidate in (f"firecrawl-{field}.json", f"firecrawl-{field}.json"):
            path = raw / candidate
            if path.exists():
                try:
                    data = json.loads(path.read_text(encoding="utf-8"))
                    if isinstance(data, dict) and field in data:
                        items = data[field]
                    elif isinstance(data, list):
                        items = data
                    else:
                        continue
                    if items:
                        result[field] = items
                        print(f"  → Ingested {len(items)} {field} from {candidate}")
                except (json.JSONDecodeError, KeyError):
                    pass
    return result


def _textacy_style(text: str) -> dict | None:
    """Textacy-powered style analysis (50+ metrics vs previous 10 hand-rolled)."""
    try:
        from textacy import text_stats, load_spacy_lang, make_spacy_doc
        from textacy.text_stats import readability, diversity, counts as ts_counts
        from textacy.extract.keyterms.textrank import textrank

        en = load_spacy_lang("en_core_web_sm", disable=("parser",))
        doc = make_spacy_doc(text, lang=en)

        return {
            "engine": "textacy",
            "n_words": text_stats.n_words(doc),
            "n_unique_words": text_stats.n_unique_words(doc),
            "n_sentences": text_stats.n_sents(doc),
            "n_long_words": text_stats.n_long_words(doc),
            "entropy": round(text_stats.entropy(doc), 4),
            "readability": {
                "flesch_kincaid": round(readability.flesch_kincaid_grade_level(doc), 2),
                "flesch_ease": round(readability.flesch_reading_ease(doc), 2),
                "smog": round(readability.smog(doc), 2) if hasattr(readability, "smog") else None,
            },
            "diversity": {
                "ttr": round(diversity.ttr(doc), 4),
                "mtld": round(diversity.mtld(doc), 2),
            },
            "pos_distribution": ts_counts.pos(doc),
            "key_terms": [(t, round(s, 4)) for t, s in textrank(doc, topn=10)],
        }
    except (ImportError, OSError):
        return None


def _jieba_style(text: str) -> dict:
    """Chinese text analysis via jieba segmentation (pure Python, no models)."""
    try:
        import jieba
        words = jieba.lcut(text)
        word_count = len(words)
        unique = len(set(words))
        top = Counter(words).most_common(20)
        return {
            "engine": "jieba",
            "word_count": word_count,
            "unique_words": unique,
            "ttr": round(unique / max(word_count, 1), 4),
            "top_words": [(w, c) for w, c in top if len(w) > 1],
        }
    except ImportError:
        return {"engine": "fallback", "error": "jieba not installed"}


def _fallback_style(text: str) -> dict:
    """Minimal style metrics when neither textacy nor jieba is available."""
    words = re.findall(r'\b\w+\b', text)
    sentences = re.split(r'[.!?。！？]+', text)
    sentences = [s for s in sentences if len(s.split()) >= 2]
    return {
        "engine": "fallback",
        "n_words": len(words),
        "n_unique_words": len(set(w.lower() for w in words)),
        "n_sentences": len(sentences),
        "avg_sentence_length": round(len(words) / max(len(sentences), 1), 1),
    }


def _strip_markdown(text: str) -> str:
    """Remove Markdown formatting to get clean prose for NLP analysis."""
    text = re.sub(r'^#{1,6}\s+', '', text, flags=re.MULTILINE)
    text = re.sub(r'\*{1,3}(.+?)\*{1,3}', r'\1', text)
    text = re.sub(r'```[\s\S]*?```', '', text)
    text = re.sub(r'`[^`]+`', '', text)
    text = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', text)
    text = re.sub(r'^[-*_]{3,}\s*$', '', text, flags=re.MULTILINE)
    text = re.sub(r'^>\s+', '', text, flags=re.MULTILINE)
    text = re.sub(r'^[\s]*[-*+]\s+', '', text, flags=re.MULTILINE)
    text = re.sub(r'^[\s]*\d+\.\s+', '', text, flags=re.MULTILINE)
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()


def _extract_tools(combined: str) -> list[dict]:
    """Extract tool and workflow preferences."""
    tools = []
    tool_mentions = [
        ("VS Code", ["vs code", "vscode"]),
        ("Vim/Neovim", ["vim", "neovim", "nvim"]),
        ("JetBrains", ["intellij", "webstorm", "pycharm", "goland"]),
        ("Emacs", ["emacs"]),
        ("iTerm", ["iterm"]),
        ("Warp", ["warp terminal"]),
        ("tmux", ["tmux"]),
        ("Homebrew", ["homebrew", "brew"]),
        ("Docker", ["docker"]),
        ("GitHub CLI", ["gh ", "github cli"]),
        ("Linear", ["linear.app", "linear"]),
        ("Notion", ["notion"]),
        ("Obsidian", ["obsidian"]),
        ("Figma", ["figma"]),
    ]
    lower = combined.lower()
    for name, aliases in tool_mentions:
        for alias in aliases:
            if alias in lower:
                tools.append({"name": name, "usage": "", "source": f"keyword:{alias}"})
                break
    return tools[:10]


def _extract_gotchas(texts: dict, combined: str) -> list[dict]:
    """Extract gotchas and anti-patterns — the highest-signal content.

    Captures both the pattern (what goes wrong) AND the fix (how to resolve it)
    by reading the sentence following each gotcha mention.
    """
    gotchas = []
    lower = combined.lower()

    # Split into sentences for fix-text extraction
    sentences_raw = re.split(r'(?<=[.!?])\s+', combined)
    sentences_lower = [s.lower() for s in sentences_raw]

    # Explicit gotcha markers — capture the pattern + next sentence as fix
    explicit_patterns = [
        r"(?:gotcha|watch out|be careful|beware|trap|pitfall|footgun):\s*(.+)",
        r"(?:common\s+(?:mistake|error|bug|pitfall))(?:\s+(?:is|with))?:\s*(.+)",
    ]

    for pattern in explicit_patterns:
        matches = re.findall(pattern, combined, re.IGNORECASE)
        for match in matches:
            text = (match[0] if isinstance(match, tuple) else match).strip()[:300]
            if text and len(text) > 15:
                # Try to find a fix in the next sentence
                fix = ""
                for i, s in enumerate(sentences_raw):
                    if text[:50].strip() in s:
                        if i + 1 < len(sentences_raw):
                            next_s = sentences_raw[i + 1].strip()
                            # Check if the next sentence looks like a fix
                            if re.search(r'(?:fix|instead|rather|solution|correct|should|use|try|replace)', next_s.lower()):
                                fix = next_s[:300]
                        break
                gotchas.append({
                    "pattern": text,
                    "fix": fix,
                    "source": "text-extraction",
                })

    # Negative pattern gotchas: "don't X because Y" or "avoid X"
    neg_patterns = [
        r"(?:don't|do\s+not|never|avoid)\s+(.+?)(?:because|since|as|—|\.)",
    ]
    for pattern in neg_patterns:
        matches = re.findall(pattern, combined, re.IGNORECASE)
        for match in matches:
            text = (match[0] if isinstance(match, tuple) else match).strip()[:300]
            if text and len(text) > 15:
                gotchas.append({
                    "pattern": text,
                    "fix": "",
                    "source": "negative-pattern",
                })

    # People-often-get-wrong patterns
    crowd_patterns = [
        r"(?:one thing|something)\s+(?:people|developers?|engineers?)\s+(?:often|always|frequently|typically)\s+(?:get wrong|miss|forget|overlook|don't realize)\s+(?:is|:)\s*(.+)",
        r"(?:the\s+(?:trick|key|secret|catch))\s+(?:is|:)\s*(.+)",
    ]
    for pattern in crowd_patterns:
        matches = re.findall(pattern, combined, re.IGNORECASE)
        for match in matches:
            text = (match[0] if isinstance(match, tuple) else match).strip()[:300]
            if text and len(text) > 15:
                gotchas.append({
                    "pattern": text,
                    "fix": "",
                    "source": "crowd-wisdom",
                })

    # Fallback: "make sure / ensure / verify / check" patterns
    if len(gotchas) < 5:
        fallback_matches = re.findall(
            r"(?:make sure|ensure|verify|check)\s+(?:that\s+)?(.+?)(?:\.|$|\n)",
            combined, re.IGNORECASE
        )
        for fm in fallback_matches[:10 - len(gotchas)]:
            gotchas.append({
                "pattern": fm.strip()[:300],
                "fix": "",
                "source": "check-pattern",
            })

    # Deduplicate
    seen = set()
    unique = []
    for g in gotchas:
        key = g["pattern"].lower()[:80]
        if key not in seen:
            seen.add(key)
            unique.append(g)

    return unique[:20]  # Rich gotcha list


def _extract_canon(combined: str) -> list[dict]:
    """Extract reference canon: papers, books, talks, repos cited."""
    canon = []
    # URL citation patterns
    url_patterns = [
        r'(?:https?://github\.com/[\w.-]+/[\w.-]+)',
        r'(?:https?://arxiv\.org/abs/[\d.]+)',
        r'(?:https?://[\w.-]+\.(?:com|org|io|dev)/[\w./-]+)',
    ]
    for pattern in url_patterns:
        matches = re.findall(pattern, combined)
        for url in matches[:10]:
            if url not in [c.get("title", "") for c in canon]:
                canon.append({
                    "title": url,
                    "type": "url",
                    "cited_in": [],
                })

    # Book/paper title patterns (quoted or italicized)
    title_matches = re.findall(r'"([^"]{10,100})"', combined)
    for title in title_matches[:5]:
        canon.append({
            "title": title,
            "type": "unknown",
            "cited_in": [],
        })

    return canon[:15]


def _assess_confidence(profile: dict) -> dict:
    """Assess confidence level for each dimension."""
    c = {"expertise": "low", "heuristics": "low", "style": "low", "gotchas": "low"}

    if len(profile["expertise"]) >= 5:
        c["expertise"] = "high"
    elif len(profile["expertise"]) >= 2:
        c["expertise"] = "medium"

    if len(profile["heuristics"]) >= 5:
        c["heuristics"] = "high"
    elif len(profile["heuristics"]) >= 2:
        c["heuristics"] = "medium"

    if profile["style"].get("phrases") and profile["style"].get("explanation_style"):
        c["style"] = "medium"
    if len(profile["style"].get("phrases", [])) >= 5:
        c["style"] = "high"

    if len(profile["gotchas"]) >= 10:
        c["gotchas"] = "high"
    elif len(profile["gotchas"]) >= 5:
        c["gotchas"] = "medium"

    return c


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_json(path: Path) -> Optional[dict]:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return None


def _now() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _print_header(title: str):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")


def _print_footer(output_path: str, profile: dict):
    print(f"\n{'='*60}")
    print(f"  Profile written to: {output_path}")
    print(f"  Expertise: {len(profile['expertise'])} domains")
    print(f"  Heuristics: {len(profile['heuristics'])} rules")
    print(f"  Gotchas: {len(profile['gotchas'])} patterns")
    print(f"  Confidence: {profile['confidence']}")
    print(f"{'='*60}\n")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Spirit Forge — Distill (炼): Extract patterns from raw research"
    )
    parser.add_argument("raw_research_dir", help="Path to raw-research directory")
    parser.add_argument("--output", default=None, help="Output path for persona-profile.json")
    args = parser.parse_args()

    profile = distill(args.raw_research_dir, args.output)
